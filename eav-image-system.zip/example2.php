<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
 require 'load.php';
 ?>
<!DOCTYPE html>
<html>
<head>
<title>EAV - Gallery Image Viewing System</title>
<link href="style.css" rel="stylesheet" type="text/css">
<style type="text/css">

</style>
</head>
<body>
<?php echo imageSystem();  ?>
<h2>Hello World!</h2><br>
<p>Did you know?<br>
You can add the image system into diffrent function in a file & tweak them & load them into you visible webpage's using the require & echo function to make them show images at certain parts of the page.
Or just make you main page code look alot simpler.</p><br>
<?php echo imageSystemTwo();  ?>

<br><br>
<p>Want to see this image system in action on a real website? <a href="http://ethan.arm64server.org" >Click here!</a></p>
</body>
</html>